class Singer:
    pass
